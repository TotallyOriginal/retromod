local open = io.open

local function read_file(path)
    local file = open(path, "rb") -- r read mode and b binary mode
    if not file then return nil end
    local content = file:read "*a" -- *a or *all reads the whole file
    file:close()
    return content
end

local function file_exists(path)
	local file = open(path, "rb")
	if file then file:close() end
	return file ~= nil
end

local function write_file(path, text)
	local file = open(path, "w")
	file:write(text)
	file:close()
end

local fileContent = read_file("gmod_path.txt")

local frameskip = 0

event.onframeend(function() 
	
end)

while true do
	if(frameskip == 10) then
		frameskip = 0
		if(file_exists(fileContent .. "\\save_state.txt")) then
			os.remove(fileContent .. "\\save_state.txt")
			savestate.saveslot(0)
			print("Saved state")
		end
		if(file_exists(fileContent .. "\\load_state.txt")) then
			os.remove(fileContent .. "\\load_state.txt")
			savestate.loadslot(0)
			print("Loaded state")
		end
		if(file_exists(fileContent .. "\\start.txt")) then
			local romname = read_file(fileContent .. "\\start.txt")
			write_file(fileContent .. "\\romname.txt", romname)
			client.openrom(fileContent .. "\\roms\\" .. romname)
			os.remove(fileContent .. "\\start.txt")
			print("Loaded ROM: " .. romname)
			print(gameinfo.getromname())
		end
		if(file_exists(fileContent .. "\\close.txt")) then
			os.remove(fileContent .. "\\close.txt")
			client.closerom()
			print("Closed ROM")
		end
	end
	frameskip = frameskip + 1
	emu.frameadvance()
end

